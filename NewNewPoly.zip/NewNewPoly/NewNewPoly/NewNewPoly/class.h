#pragma once
#include <string>

#ifndef CLASS_H
#define CLASS_H

//base class for all characters
class character
{
protected:
	//prtected variables
	int max_health;
	int max_stamina;
public:
	//constructor
	character(int mh, int ms) { max_health = mh; max_stamina = ms; }

	//class members
	void set_mh(int mh);
	void set_ms(int ms);
	int get_mh() const;
	int get_ms() const;
};

//zombie subclass
class zombie : public character
{
protected:
	//protected variables
	std::string z_type;
	int z_speed;

public:
	//constructor for class and base class
	zombie(int mh, int ms) : character(mh, ms){}

	//class members
	void set_z_type(std::string);
	void set_z_speed(int s);
	std::string get_z_type();
	int get_z_speed();

	//prints subsets of class variables
	void printInfo(bool x);
	void printInfo(int x);

};

//alien subclass
class alien : public character
{
protected:
	//protected variables
	std::string a_type;
	int a_speed;

public:
	//constructor for class and base class
	alien(int mh, int ms) : character(mh, ms){}

	//class members
	void set_a_type(std::string);
	void set_a_speed(int s);
	std::string get_a_type();
	int get_a_speed();

	//prints subsets of class variables
	void printInfo(bool x);
	void printInfo(int x);

};




#endif